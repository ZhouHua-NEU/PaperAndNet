Instructions:

Download and unzip this toolbox in the location of choice. To
setup this toolbox, simply open matlab, cd to this directory, and type "setup" 
(without the quotes) in the command window. This sets up your path to include the required
directories (you may want to add these paths into your startup.m file as well
however) and opens complete documentation for this toolbox. 
Then you can modify parameters within /Defaults/set_defaults_here.m
and run any of the scripts listed below (RUN THEM FROM THIS DIRECTORY as the 
results will be added to ./Results/ whereever you are running from).

The main scripts to run (from the main directory) are:
  train.m - trains a Deconvoltuional Network using specified parameters.
  recon.m - reconstructs input images using a previously trained
Deconvolutional Network.
  top_down.m - loads previously trained top layer (and all layers below)
and visualizes the top layer's filters in pixel space.
  top_down_sampling.m - load previously trained top layer (and all layers
below), samples from the distribution of the top feature maps over the
training set the model was trained with, and shows this in pixel space.

License:

Permission is granted for anyone to copy, use, modify, or distribute this
program and accompanying programs and documents for any purpose, provided
this copyright notice is retained and prominently displayed, along with
a note saying that the original programs are available from our
web page.
The programs and documents are distributed without any warranty, express or
implied.  As the programs were written for research purposes only, they have
not been tested to the degree that would be advisable in any important
application.  All use of these programs is entirely at the user's own
risk.