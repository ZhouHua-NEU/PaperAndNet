%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%>
% @mainpage Documentation for Deconvolutional Network Toolbox
%
% <div class="version_description">
% @author Matthew Zeiler (zeiler@cs.nyu.edu)
% @date Apr 4, 2010
% @version 1.0.1 - A few bugs were fixed with plotting and saving figures. Also,
% the MATLABCentral convnfft.m file is now supported for enhanced performance 
% during training (though not included with this package).
%
% </div>
%
% <div class="website_description">
% This toolbox includes code that implements a Deconvolutional Network as described
% in the paper <a href="http://www.matthewzeiler.com/pubs/cvpr2010/cvpr2010.pdf">
% Deconvolutional Networks</a>. This has a function to train a Deconvolutional
% Network, to visualize the learned filters, and to recsontruct a new image from
% a trained model. Also, there are files that can be used to make descriptors
% that can be used with <a href="http://www.cs.unc.edu/~lazebnik/research/spatial_pyramid_code.zip">
% Svetlana Lazebnik's Spatial Pyramid Matching
% code</a> with a few minor modifications. The Deconvolutional Network Toolbox
% also works with the <a href="http://www.matthewzeiler.com/software/IPPConvsToolbox/IPPConvsToolbox.zip">
% IPP Convolutions Toolbox</a> which drastically improves performance (just
% ensure the IPP Convolutions Toolbox files are in your MATLAB path in order to
% use it with this toolbox). If you do not have IPP libraries, you can still get
% a significant performance enhancement by using <a
% href="http://www.mathworks.com/matlabcentral/fileexchange/24504-fft-based-conv
% olution">convnfft.m</a> from MATLABCentral.
%
% </div>
%
% <div class="instructions">
% @instructions Download and unzip this toolbox in the location of choice. To
% setup this toolbox, simply open matlab, cd to this directory, and type "setup"
% (without the quotes) in the command window. This sets up your path to include the required
% directories (you may want to add these paths into your startup.m file as well
% however) and opens complete documentation for this toolbox. 
% Then you can modify parameters within /Defaults/set_defaults_here.m
% and run any of the scripts listed below (RUN THEM FROM THIS DIRECTORY as the 
% results will be added to ./Results/ whereever you are running from).
%
% </div>
%
% Running the README.m file will add the required directories to the MATLAB path
% and open the included html documentation for the toolbox.
%
% If you find it slow to train or reconstruct, set PLOT_RESULTS=0 and
% DISPLAY_ERRORS = 0.
%
% The parameters are set within /Defaults/set_defaults_here.m.
%
% The main scripts to run are:
% \li \e train.m trains a Deconvoltuional Network using specified parameters.
% \li \e recon.m reconstructs input images using a previously trained
% Deconvolutional Network.
% \li \e top_down.m loads previously trained top layer (and all layers below)
% and visualizes the top layer's filters in pixel space.
% \li \e top_down_sampling.m load previously trained top layer (and all layers
% below), samples from the distribution of the top feature maps over the
% training set the model was trained with, and shows this in pixel space.
%
%
% The main folders included in the Toolbox are as follows:
% \li \e Connectivity_Matrices define the structure of connections between each
% layer.
% \li \e Datasets some sample images to train/reconstruct with.
% \li \e Defaults contains the file set_defaults_here.m where you set all the
% parameters for each experiment.
% \li \e Helper various tools needed for plotting, file manipulation,
% normalizing, etc.
% \li \e Image_Functions files for the preprocessing of the images
% \li \e Inference functions for inferring z and z0 feautre maps.
% \li \e Layer the per layer training and reconstruction files.
% \li \e Learn_Filters functions for updating the filters.
% \li \e Reconstructing the main high level function for reconstructing an image
% from a trained model.
% \li \e SPM code to make descriptors for Svetlana Lazebnik's Spatial Pyramid
% Matching kernel algorithm.
% \li \e Subsamplign functions for pooling.
% \li \e Top_Down functions for visualizing upper layer filters in pixel space.
% \li \e Training the main high level functions for training the model.
%
% @license Permission is granted for anyone to copy, use, modify, or distribute this
% program and accompanying programs and documents for any purpose, provided
% this copyright notice is retained and prominently displayed, along with
% a note saying that the original programs are available from our
% web page.
% The programs and documents are distributed without any warranty, express or
% implied.  As the programs were written for research purposes only, they have
% not been tested to the degree that would be advisable in any important
% application.  All use of these programs is entirely at the user's own
% risk.
%
% @bug Please report any bugs to zeiler@cs.nyu.edu.
%
% @todo Continue commenting the code more thoroughly in the body of functions.
% @todo Clean-up many files, expecially train_recon_layer and move figure
% plotting into scripts outside that function.
% @todo Move the autogenerating save paths from the gui into a script so it can
% be used by train and recon.
% @todo We know of an issue where the parameters don't scale properly with the
% size of the training images and so nice filters are not learned for some sizes.
% 100x100 images seem to work best. We have some theories as to why this is happening
% and will try to correct this in the near future.
%
% @prevversions 
% \li 1.0.0 - This is the initial release of this toolbox and may contain
% unkown bugs. 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


fprintf('Fist make sure you are running this README.m from its directory.\n');

fprintf('Adding paths now...\n')
addpath(genpath(strcat(pwd,'/Connectivity_Matrices')))
addpath(genpath(strcat(pwd,'/Defaults')))
addpath(genpath(strcat(pwd,'/Helper')))
addpath(genpath(strcat(pwd,'/Image_Functions')))
addpath(genpath(strcat(pwd,'/Inference')))
addpath(genpath(strcat(pwd,'/Layer')))
addpath(genpath(strcat(pwd,'/Learn_Filters')))
addpath(genpath(strcat(pwd,'/Reconstructing')))
addpath(genpath(strcat(pwd,'/SPM')))
addpath(genpath(strcat(pwd,'/Subsampling')))
addpath(genpath(strcat(pwd,'/Top_Down')))
addpath(genpath(strcat(pwd,'/Training')))


fprintf('Opening the HTML documentation in a browser now...\n');
try
    open([pwd '/Documentation/index.html'])
catch ME
    fprintf('Either path is incorrect to Documentation, or you are not running with java enabled\n');
end





