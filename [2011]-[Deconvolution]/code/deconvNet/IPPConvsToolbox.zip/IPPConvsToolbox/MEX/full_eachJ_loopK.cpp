/*!
 * @brief MEX wrapper for IPP and OpenMP implementation of: 
 * \f[
 *   out(:,:,j,k) = g_{j,k}(y_j \oplus_{full} f^j_k))
 * \f]
 * where for each input map (prhs[0]) j (ie y(:,:,j)), it is convolved with each filter (prhs[1])
 * over all k for that specific j (ie f(:,:,j,k)) using a 'full' convolution if  the
 * binary connectivity matrix has g(j,k) == 1. . 
 *
 * In terms of the input arguments this would be written as:
 * \f[
 *  OUTPUT(:,:,j,k) = CONMAT(j,k)(MAPS(:,:,j) \oplus_{full} FILTERS(:,:,j,k))
 * \f]
 *
 * This is commonly used in the inference and learning filters of a Deconvolutional
 * Network (along with sumk_zk_fjk) by doing a summation OUTSIDE this function (this function merely sets
 * up for this summation with an outsize1 x outsize2 x num_input_maps(aka J) x
 * num_feature_maps(aka K) result. See the example usage below.
 * \f[
 *   out(:,:,k) = \sum_j g_{j,k}((\sum_k g_{j,k}(z(:,:,k) \oplus_{valid} f^j_k)) \oplus_{full} f(:,:,j,k)^*)
 * \f]
 * where * is the flipup(fliplr()) operation in MATLAB.
 *
 * Note: the summation is done OUTSIDE this function (this function merely sets
 * up for this summation with an outsize1 x outsize2 x num_input_maps(aka J) x
 * num_feature_maps(aka K) result. See the MATLAB example usage below.
 * 
 * An example MATLAB usage could be:<br>
 * out = sum(sumk_zk_fjk( y , Fflip , conmat, [COMP_THREADS] ),3);
 *
 * @file
 * @author Matthew Zeiler
 * @data Mar 11, 2010
 *
 * @ipp_file @copybrief full_eachJ_loopK.cpp
 *
 * Requirements:
 *   \li A system with one or more multi-core Intel 64-bit CPU's
 *   \li Up to date installations of:
 *       1) Intel 64-bit C compiler (tested on version current)
 *       2) Intel Integrated Performance Primitive (IPP) libraries (tested on version 5.3)
 *   \li Matlab - to actually use the MEX file (tested on 7.5.0.338 (R2007b))
 *
 * Points to note:
 *
 * 1. These environment variables that need to be set in bash before running the mex file:
 * export PATH="/opt/intel/cce/current/bin:${PATH}";
 * export LD_LIBRARY_PATH="/opt/intel/cce/current/lib:${LD_LIBRARY_PATH}";
 *
 * 2.  The IPP libraries will automatically swap to using Fourier domain ...
 * multiplication once the size of the kernel is above 15x15 or so.
 *
 * 3. I've no idea why the valid convolution is so much faster than the full one.
 * 
 * 
 * 
 ***************** 
 * How to compile:
 *
 * Type in Matlab to compile:<br>
 * >> mex -f ./Helper/ipp/mexopts.sh -I/opt/intel/ipp/current/em64t/include -L/opt/intel/ipp/current/em64t/lib  -L/opt/intel/cce/current/lib -lguide  -lippiemergedem64t -lippimergedem64t  -lippcoreem64t  -lippsemergedem64t   -lippsmergedem64t  -lstdc++ full_eachJ_loopK.cpp
 *
 * Normal output:<br>
 * full_eachJ_loopK.cpp(229): (col. 1) remark: OpenMP DEFINED LOOP WAS PARALLELIZED.<br>
 * >>
 *
 * Note that you will need to change the paths in the command to find (i) the IPP libraries (ii) Intel compiler on your system and (iii) the customized mexopts.sh file - see below.
 *****************
 *
 * You will need to alter the mexopts.sh file that Matlab uses. We have included one with 
 * this package, but you may have to alter it. Then alter the -f option in the mex ...
 * command above to call it.
 *
 *
*/



#include <mex.h> // Mex header
#include <stdio.h>
#include <ipp.h> // Intel IPP header
#include <math.h>
#include <string.h>

#ifdef MULTITHREADING_OMP
#include <omp.h> // OpenMP header
#endif

#define MAX_NUM_THREADS      4 // Max number of parallel threads that the ...
//code will try to use (Integer). Set to 1 if you want to use a single core ...
//    (typical speedup over Matlab's conv2/fft2 is 3.5x). Set >1 for ...
//    multithreading. This number should be less than the #cpus per ...
//    machine x #cores/cpu. i.e. a machine which two quad-core cpu's ...
//    could have upto 8 threads. Note that if there are fewer images than threads
//    then the code will automatically turn down the number of threads (since the extra ones do nothing except waste
//    resources.

// Input Arguments
#define	MAPS   	        prhs[0] // The stack of images you want to convolve: n x m x c matrix of single precision floating point numbers.
#define FILTERS         prhs[1] // The kernel: i x j x c matrix of single precision floating point numbers.
#define CONMAT          prhs[2] // Connectivity Matrix
#define INPUT_THREADS   prhs[3] // User can optionally input the number of computation threads to parallelized over.

// Output Arguments
#define	OUTPUT   	plhs[0] // Convolved stack of images. If in valid mode, this will be (n-i+1) x (m-j+1) x c  matrix of single ...
//  precision floating point numbers. If in full mode, this will be  (n+i-1) x (m+j-1) x c  matrix of single ...
//  precision floating point numbers.

/*!
 * @copybrief full_eachJ_loopK.cpp
 *
 * @param MAPS (this is prhs[0]) n x m x num_input_maps  matrix of single precision floating point numbers.
 * @param FILTERS (this is prhs[1]) p x q x num_input_maps x num_feature_maps matrix of single precision floating point numbers.
 * @param CONMAT (this is prhs[2]) num_input_maps x num_feature_maps connectivity matrix.
 * @param INPUT_THEADS (this is prhs[3] and is optional) specifies number of computation threads to parallelize over. Defaults to 4.
 *
 * @retval out (this is plhs[0]) A 4D matrix of (n+p-1) x (m+q-1) x num_input_maps x num_feature_maps
 */
void mexFunction( int nlhs, mxArray *plhs[],
        int nrhs, const mxArray*prhs[] )
        
{
    unsigned int image_x, image_y, kernel_x, kernel_y, output_x, output_y;
    int status, num_images, num_kernels, i, j, k, k_num_dims, num_dims, c_num_dims, number_threads;
    int num_input_maps, num_feature_maps;
    float *kernelp, *imagep, *outputp, *kernelp_base, *imagep_base, *outputp_base, *conmatp, *conmatp_base;
    int *number_threadsp;
    
    IppStatus retval;
    IppiSize output_size, kernel_size, image_size, conmat_size;
    const mwSize *imagedims;
    const mwSize *kerneldims;
    const mwSize *conmatdims;
    int outputdims[4];
    // 0 for multiple images single kernel
    // 1 for multiple kernels single image
    // 2 for multiple kernels multiple images
    
    // Check for proper number of arguments
    if (nrhs < 3) {
        mexErrMsgTxt("Three input arguments required at minimum.");
    } else if (nlhs > 1) {
        mexErrMsgTxt("Too many output arguments.");
    }
    
    // If number of threads was not input, then use default set abvoe.
    if (nrhs < 4)
        number_threads = MAX_NUM_THREADS;
    else
        number_threads = (int)mxGetScalar(INPUT_THREADS);
    
//     mexPrintf("%d is the number of threads\n",number_threads);
    
    // MAPS must be a single.
    if (mxIsSingle(MAPS) != 1)
        mexErrMsgTxt("Image must be a single precision (float), not double.");
    
    // MAPS must be 3-D stack of images
    // Uncomment if you only want this to run on stacks of images
    //if (mxGetNumberOfDimensions(MAPS) != 3)
    //  mexErrMsgTxt("Image must be a 3D array of images.");
    
    // Input must be a single.
    if (mxIsSingle(FILTERS) != 1)
        mexErrMsgTxt("Kernel must be a single precision (float), not double.");
    
    // Get dimensions of image and kernel
    num_dims = mxGetNumberOfDimensions(MAPS);
    imagedims = (mwSize*) mxCalloc(num_dims, sizeof(mwSize));
    imagedims = mxGetDimensions(MAPS);
    
    image_size.width = imagedims[0];
    image_size.height = imagedims[1];
    
    k_num_dims = mxGetNumberOfDimensions(FILTERS);
    kerneldims = (mwSize*) mxCalloc(k_num_dims, sizeof(mwSize));
    kerneldims = mxGetDimensions(FILTERS);
    
    kernel_size.width = kerneldims[0];
    kernel_size.height = kerneldims[1];
    
    c_num_dims = mxGetNumberOfDimensions(CONMAT);
    conmatdims = (mwSize*) mxCalloc(c_num_dims, sizeof(mwSize));
    conmatdims = mxGetDimensions(CONMAT);
    
    num_input_maps = conmatdims[0];
    num_feature_maps = conmatdims[1];
    conmat_size.width = conmatdims[0];
    conmat_size.height = conmatdims[1];
    
    if (num_dims == 2)
        num_images = 1;
    else
        num_images = imagedims[2];
    
    if (k_num_dims == 2)
        num_kernels = 1;
    else
        num_kernels = kerneldims[2];
    
//     mexPrintf("%d images at %d by %d\n", num_images, image_size.width, image_size.height);
//     mexPrintf("%d kernels at %d by %d\n", num_kernels, kernel_size.width, kernel_size.height);
//     mexPrintf("Conmat is %d by %d\n",num_input_maps,num_feature_maps);
    //mexPrintf("Mixing Type: %d\n", MIXING_TYPE);
    
    // Get pointers to MAPS and FILTERS
    imagep_base = (float*) mxGetData(MAPS);
    kernelp_base = (float*) mxGetData(FILTERS);
    conmatp_base = (float*) mxGetData(CONMAT);
    
    // *****************************************************************************************************
    // Main part of code
    // Always a full convolution.
    
    // Create output matrix of appropriate size
    output_size.width  = image_size.width  + kernel_size.width - 1;
    output_size.height = image_size.height + kernel_size.height - 1;
    outputdims[1] = output_size.height;
    outputdims[0] = output_size.width;
    
    // Arrange the outpu dimensions like F (outSize x outSize x num_input_maps x num_feature_maps)
    outputdims[2] = num_input_maps;
    outputdims[3] = num_feature_maps; // This is what should be summed over outside with sum(...,4)
    OUTPUT = mxCreateNumericArray(4, outputdims, mxSINGLE_CLASS, mxREAL);
    
    // Check matrix generated OK
    if (OUTPUT==NULL)
        mexErrMsgTxt("Could not allocate output array");
    
    // Get pointer to output matrix
    outputp_base = (float*) mxGetData(OUTPUT);
    
    if (outputdims[2]<number_threads)
        number_threads= outputdims[2];
    
    // Setup openMP for core inner loop
    // Have to ensure the pointers are private variables to each thread.
//#pragma omp parallel for num_threads(number_threads) shared(imagep_base, kernelp_base, outputp_base, output_size, kernel_size, image_size, outputdims) private(i, imagep, kernelp, outputp)
#pragma omp parallel for num_threads(number_threads) private(j, k, imagep, kernelp, outputp, conmatp)

// Main loop over all images in stack. Stuff inside this loop ...
// will be multi-threaded out to different cores.
for (j=0;j<num_input_maps;j++){
    // Looping over the image planes.
    imagep = imagep_base + (j*image_size.width*image_size.height);
    
    for(k=0;k<num_feature_maps;k++){
        // Update the pointer in the connectivity matrix.
        conmatp = conmatp_base + (k*conmat_size.width) + (j*conmat_size.width/num_input_maps);
//         mexPrintf("Size of float: %d\n",sizeof(float));
        
        if(*conmatp == 1){
//         mexPrintf("conbase: %p %f j: %d k: %d conmatp: %p %f\n",conmatp_base,*conmatp_base,j,k,conmatp,*conmatp);
            
            // set pointer offset for kernel
            kernelp = kernelp_base + (j*kernel_size.width*kernel_size.height) + (k*num_input_maps*kernel_size.width*kernel_size.height);
            // set pointer offset for output in it's 4D array.
            outputp = outputp_base + (j*output_size.width*output_size.height) + (k*num_input_maps*output_size.width*output_size.height);
            
//         mexPrintf("I: %d K: %d ip: %p %f op: %p %f kp: %p %f\n", j,k, imagep, *imagep, outputp, *outputp, kernelp, *kernelp);
            retval = ippiConvFull_32f_C1R(imagep, sizeof(float)*image_size.width, image_size, kernelp, sizeof(float)*kernel_size.width, kernel_size, outputp, sizeof(float)*output_size.width);
        }
    }
}

// Parse any error (can't put inside inner loop as it will stop ...
//  multithreading)
if (retval!=ippStsNoErr){
    mexPrintf("Error performing convolution\n");
    
    if (retval==ippStsNullPtrErr)
        mexErrMsgTxt("Pointers are NULL\n");
    
    if (retval==ippStsSizeErr)
        mexErrMsgTxt("Sizes negative or zero\n");
    
    if (retval==ippStsStepErr)
        mexErrMsgTxt("Steps negative or zero\n");
    
    if (retval==ippStsMemAllocErr)
        mexErrMsgTxt("Memory allocation error\n");
    
}




return;

}

